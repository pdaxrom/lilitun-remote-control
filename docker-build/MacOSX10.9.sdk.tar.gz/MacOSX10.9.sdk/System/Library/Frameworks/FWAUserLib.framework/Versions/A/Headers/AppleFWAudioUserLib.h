/*
     File:     AppleFWAudioUserLib.h
 
     Contains:  Public API for AppleFWAudio driver userclient
 
     Version:   Mac OS X
 
     Copyright: � 2005-2010 by Apple Computer, Inc., all rights reserved.
 
     Bugs?:      For bug reports, consult the following page on
                 the World Wide Web:
 
                     http://developer.apple.com/bugreporter/
*/

#include <FWAUserLib/FWAUserLib.h>

#warning this file is deprecated use FWAUserLib.h instead.