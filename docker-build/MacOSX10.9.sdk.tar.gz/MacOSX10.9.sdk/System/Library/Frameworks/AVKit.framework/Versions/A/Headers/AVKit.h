/*
 File:  AVKit.h
 
 Framework:  AVKit
 
 Copyright 2011-2013 Apple Inc. All rights reserved.
 
 To report bugs, go to:  http://developer.apple.com/bugreporter/
 
 */

#import <AVKit/AVPlayerView.h>
