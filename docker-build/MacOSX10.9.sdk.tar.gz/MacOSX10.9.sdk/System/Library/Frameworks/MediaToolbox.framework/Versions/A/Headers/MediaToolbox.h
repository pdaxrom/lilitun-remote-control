/*
	File:  MediaToolbox.h

	Framework:  MediaToolbox

	Copyright 2012-2013 Apple Inc. All rights reserved.

	To report bugs, go to:  http://developer.apple.com/bugreporter/
*/

#include <MediaToolbox/MTAudioProcessingTap.h>
