#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIPlugIn.h>
