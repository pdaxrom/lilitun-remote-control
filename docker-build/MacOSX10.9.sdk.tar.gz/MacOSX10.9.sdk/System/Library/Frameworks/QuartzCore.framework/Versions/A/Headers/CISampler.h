#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CISampler.h>
