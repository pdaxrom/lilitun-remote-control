#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIVector.h>
