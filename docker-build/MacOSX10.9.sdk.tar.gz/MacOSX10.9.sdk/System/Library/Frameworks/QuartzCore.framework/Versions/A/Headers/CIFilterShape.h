#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIFilterShape.h>
