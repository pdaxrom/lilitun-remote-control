#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIRAWFilter.h>
