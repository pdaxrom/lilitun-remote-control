#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIKernel.h>
