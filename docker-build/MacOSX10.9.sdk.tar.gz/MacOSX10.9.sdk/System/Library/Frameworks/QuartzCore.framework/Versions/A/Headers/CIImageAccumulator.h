#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIImageAccumulator.h>
