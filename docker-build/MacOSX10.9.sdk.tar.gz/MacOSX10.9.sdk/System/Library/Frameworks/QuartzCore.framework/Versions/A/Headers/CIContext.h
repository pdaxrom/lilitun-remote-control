#include <QuartzCore/../Frameworks/CoreImage.framework/Headers/CIContext.h>
